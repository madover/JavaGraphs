package roadgraph;

//This class is used to contain a data about all edges on the map
import geography.GeographicPoint;

public class GraphEdge implements Comparable<GraphEdge>{
	
	private GeographicPoint from;
	private GeographicPoint to;
	private String roadName;
	private String roadType;
	private double length;
	
	public GraphEdge(GeographicPoint from, GeographicPoint to, String roadName,
			String roadType, double length) {
		this.from = from;
		this.to = to;
		this.roadName = roadName;
		this.roadType = roadType;
		this.length = length;
	}
	
	public GeographicPoint getFrom(){
		return this.from;
	}
	
	public GeographicPoint getTo(){
		return this.to;
	}
	
	public String getRoadName(){
		return this.roadName;
	}
	
	public String getRoadType(){
		return this.roadType;
	}
	
	public double getLength(){
		return this.length;
	}
	
	@Override
	
	public int compareTo(GraphEdge o) {
		
		return ((Double)this.length).compareTo(o.getLength());
		
	}
}
